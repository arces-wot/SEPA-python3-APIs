"""
The sepy module: a client library to interact with
SPARQL Event Processing Architectures (aka SEPAs).
"""

__version__ = '1.0.0'

__author__ = 'Fabio Viola <fabio.viola@unibo.it>, Francesco Antoniazzi <francesco.antoniazzi@unibo.it>'