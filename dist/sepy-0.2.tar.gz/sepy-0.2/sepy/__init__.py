"""
The sepy module: a client library to interact with
SPARQL Event Processing Architectures (aka SEPAs).
"""
